def add(x = 0,y = 0) :
    return x + y

def subtract(x,y):
    return x-y

def multiplication(x = 0,y = 0):
    return x*y